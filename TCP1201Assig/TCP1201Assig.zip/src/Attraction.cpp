#include "Attraction.h"

Attraction::Attraction()
{
    //ctor
}

Attraction::~Attraction()
{
    //dtor
}

void Attraction::display()
{

}
