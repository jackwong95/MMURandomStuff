#include "Culture.h"

Culture::Culture()
{
    //ctor
}

Culture::~Culture()
{
    //dtor
}
